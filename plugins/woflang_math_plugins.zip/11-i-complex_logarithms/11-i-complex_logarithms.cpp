// 11-i-complex_logarithms.cpp
// Implementation for math plugin: 11-i-complex_logarithms

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
