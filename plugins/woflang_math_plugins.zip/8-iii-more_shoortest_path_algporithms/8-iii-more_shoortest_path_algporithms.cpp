// 8-iii-more_shoortest_path_algporithms.cpp
// Implementation for math plugin: 8-iii-more_shoortest_path_algporithms

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
