// 12-cryptographic_functions.cpp
// Implementation for math plugin: 12-cryptographic_functions

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
