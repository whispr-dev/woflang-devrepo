// 5-iii-gradient_and_hessian.cpp
// Implementation for math plugin: 5-iii-gradient_and_hessian

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
