// 9-iii-something_about_hulls.cpp
// Implementation for math plugin: 9-iii-something_about_hulls

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
