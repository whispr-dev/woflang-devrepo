// 11-ii-complex_exponentiation.cpp
// Implementation for math plugin: 11-ii-complex_exponentiation

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
