// 8-ii-fast_searching_graphs.cpp
// Implementation for math plugin: 8-ii-fast_searching_graphs

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
