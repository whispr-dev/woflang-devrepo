// 15-i-igraph_colouring.cpp
// Implementation for math plugin: 15-i-igraph_colouring

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
