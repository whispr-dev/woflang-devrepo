// -calculus_and_graph_theory.cpp
// Implementation for math plugin: -calculus_and_graph_theory

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
