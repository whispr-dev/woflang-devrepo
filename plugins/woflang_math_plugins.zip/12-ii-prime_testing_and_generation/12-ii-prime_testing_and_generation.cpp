// 12-ii-prime_testing_and_generation.cpp
// Implementation for math plugin: 12-ii-prime_testing_and_generation

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
