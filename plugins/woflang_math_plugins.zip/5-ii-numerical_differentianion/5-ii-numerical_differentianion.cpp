// 5-ii-numerical_differentianion.cpp
// Implementation for math plugin: 5-ii-numerical_differentianion

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
