// 5-i-numerical_integration.cpp
// Implementation for math plugin: 5-i-numerical_integration

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
