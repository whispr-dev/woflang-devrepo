// 8-i-shortest_path_algorithms.cpp
// Implementation for math plugin: 8-i-shortest_path_algorithms

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
