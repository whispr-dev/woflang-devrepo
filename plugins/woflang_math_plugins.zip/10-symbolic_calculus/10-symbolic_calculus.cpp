// 10-symbolic_calculus.cpp
// Implementation for math plugin: 10-symbolic_calculus

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
