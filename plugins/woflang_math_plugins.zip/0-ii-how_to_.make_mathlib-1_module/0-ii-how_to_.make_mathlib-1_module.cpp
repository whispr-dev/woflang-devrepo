// 0-ii-how_to_.make_mathlib-1_module.cpp
// Implementation for math plugin: 0-ii-how_to_.make_mathlib-1_module

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
