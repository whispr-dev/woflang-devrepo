// 15-i-permutations_of_arrangements.cpp
// Implementation for math plugin: 15-i-permutations_of_arrangements

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
