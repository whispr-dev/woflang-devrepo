// 0-contents#_of_this_archive.cpp
// Implementation for math plugin: 0-contents#_of_this_archive

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
