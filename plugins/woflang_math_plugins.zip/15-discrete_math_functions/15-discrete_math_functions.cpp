// 15-discrete_math_functions.cpp
// Implementation for math plugin: 15-discrete_math_functions

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
