// x-unicode_advanced_math_library.cpp
// Implementation for math plugin: x-unicode_advanced_math_library

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
