// 0-i-what_should_be_in_adv_math.cpp
// Implementation for math plugin: 0-i-what_should_be_in_adv_math

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
