// 10-i-moar_symbolic_dif_and_int.cpp
// Implementation for math plugin: 10-i-moar_symbolic_dif_and_int

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
