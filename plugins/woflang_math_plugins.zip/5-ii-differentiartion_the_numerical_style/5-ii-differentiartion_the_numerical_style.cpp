// 5-ii-differentiartion_the_numerical_style.cpp
// Implementation for math plugin: 5-ii-differentiartion_the_numerical_style

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
