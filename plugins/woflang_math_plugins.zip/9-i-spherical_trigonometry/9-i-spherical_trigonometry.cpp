// 9-i-spherical_trigonometry.cpp
// Implementation for math plugin: 9-i-spherical_trigonometry

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
