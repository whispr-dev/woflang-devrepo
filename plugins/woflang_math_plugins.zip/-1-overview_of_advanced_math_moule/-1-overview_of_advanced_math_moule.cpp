// -1-overview_of_advanced_math_moule.cpp
// Implementation for math plugin: -1-overview_of_advanced_math_moule

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
