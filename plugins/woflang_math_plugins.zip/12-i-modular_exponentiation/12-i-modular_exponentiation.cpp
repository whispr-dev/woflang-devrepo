// 12-i-modular_exponentiation.cpp
// Implementation for math plugin: 12-i-modular_exponentiation

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
