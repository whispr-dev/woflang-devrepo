// 10-ii-algebraic_expression_reduction.cpp
// Implementation for math plugin: 10-ii-algebraic_expression_reduction

#include "wof_interpreter.hpp"

// TODO: Add opcode bindings here
