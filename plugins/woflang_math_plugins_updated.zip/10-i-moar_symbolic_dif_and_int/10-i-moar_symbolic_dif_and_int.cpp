#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 10-i-moar_symbolic_dif_and_int
// TODO: Implement operations for advanced math

void register_10-i-moar_symbolic_dif_and_int_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3010, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[10-i-moar_symbolic_dif_and_int] Executing ƒ1 (opcode 3010)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3011, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[10-i-moar_symbolic_dif_and_int] Executing ƒ2 (opcode 3011)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
