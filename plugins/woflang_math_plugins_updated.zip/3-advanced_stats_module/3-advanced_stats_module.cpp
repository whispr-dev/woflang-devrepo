#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 3-advanced_stats_module
// TODO: Implement operations for advanced math

void register_3-advanced_stats_module_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3040, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[3-advanced_stats_module] Executing ƒ1 (opcode 3040)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3041, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[3-advanced_stats_module] Executing ƒ2 (opcode 3041)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
