#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 8-i-shortest_path_algorithms
// TODO: Implement operations for advanced math

void register_8-i-shortest_path_algorithms_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3050, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[8-i-shortest_path_algorithms] Executing ƒ1 (opcode 3050)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3051, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[8-i-shortest_path_algorithms] Executing ƒ2 (opcode 3051)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
