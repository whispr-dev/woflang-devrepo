#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 12-ii-prime_testing_and_generation
// TODO: Implement operations for advanced math

void register_12-ii-prime_testing_and_generation_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3028, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[12-ii-prime_testing_and_generation] Executing ƒ1 (opcode 3028)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3029, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[12-ii-prime_testing_and_generation] Executing ƒ2 (opcode 3029)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
