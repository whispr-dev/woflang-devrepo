#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 15-discrete_math_functions
// TODO: Implement operations for advanced math

void register_15-discrete_math_functions_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3030, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[15-discrete_math_functions] Executing ƒ1 (opcode 3030)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3031, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[15-discrete_math_functions] Executing ƒ2 (opcode 3031)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
