#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 15-iii-sorting_and_something_algorithms
// TODO: Implement operations for advanced math

void register_15-iii-sorting_and_something_algorithms_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3038, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[15-iii-sorting_and_something_algorithms] Executing ƒ1 (opcode 3038)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3039, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[15-iii-sorting_and_something_algorithms] Executing ƒ2 (opcode 3039)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
