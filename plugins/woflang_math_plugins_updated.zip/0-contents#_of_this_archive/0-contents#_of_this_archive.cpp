#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 0-contents#_of_this_archive
// TODO: Implement operations for advanced math

void register_0-contents#_of_this_archive_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3004, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[0-contents#_of_this_archive] Executing ƒ1 (opcode 3004)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3005, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[0-contents#_of_this_archive] Executing ƒ2 (opcode 3005)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
