#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 0-ii-how_to_.make_mathlib-1_module
// TODO: Implement operations for advanced math

void register_0-ii-how_to_.make_mathlib-1_module_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3008, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[0-ii-how_to_.make_mathlib-1_module] Executing ƒ1 (opcode 3008)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3009, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[0-ii-how_to_.make_mathlib-1_module] Executing ƒ2 (opcode 3009)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
