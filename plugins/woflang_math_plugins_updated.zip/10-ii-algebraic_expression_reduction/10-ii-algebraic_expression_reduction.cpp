#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 10-ii-algebraic_expression_reduction
// TODO: Implement operations for advanced math

void register_10-ii-algebraic_expression_reduction_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3012, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[10-ii-algebraic_expression_reduction] Executing ƒ1 (opcode 3012)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3013, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[10-ii-algebraic_expression_reduction] Executing ƒ2 (opcode 3013)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
