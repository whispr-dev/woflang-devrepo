#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 0-i-what_should_be_in_adv_math
// TODO: Implement operations for advanced math

void register_0-i-what_should_be_in_adv_math_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3006, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[0-i-what_should_be_in_adv_math] Executing ƒ1 (opcode 3006)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3007, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[0-i-what_should_be_in_adv_math] Executing ƒ2 (opcode 3007)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
