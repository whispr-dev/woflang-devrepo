#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: -1-overview_of_advanced_math_moule
// TODO: Implement operations for advanced math

void register_-1-overview_of_advanced_math_moule_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3000, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[-1-overview_of_advanced_math_moule] Executing ƒ1 (opcode 3000)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3001, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[-1-overview_of_advanced_math_moule] Executing ƒ2 (opcode 3001)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
