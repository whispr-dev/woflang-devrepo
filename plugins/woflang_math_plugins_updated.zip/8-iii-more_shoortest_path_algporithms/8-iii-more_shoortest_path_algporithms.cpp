#include "wof_interpreter.hpp"
#include <iostream>

// Plugin: 8-iii-more_shoortest_path_algporithms
// TODO: Implement operations for advanced math

void register_8-iii-more_shoortest_path_algporithms_plugin(WofInterpreter& vm) {
    vm.registerOpcode(3056, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[8-iii-more_shoortest_path_algporithms] Executing ƒ1 (opcode 3056)\n";
        // Example: vm.push(vm.pop() + vm.pop());
    });
    vm.registerOpcode(3057, [](WofInterpreter& vm, const WofToken& token) {
        std::cout << "[8-iii-more_shoortest_path_algporithms] Executing ƒ2 (opcode 3057)\n";
        // Example: vm.push(vm.pop() * 2);
    });
}
